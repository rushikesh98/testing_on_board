########################################################################
#
#                           Blinky.eww
#
# $Revision: 31601 $
#
########################################################################

DESCRIPTION
===========
   This example project shows how to use the IAR Embedded Workbench
  for ARM to develop code for the OLIMEX STM32-H103 board. It uses timer
  interrupts to toggle the STAT LED  on the board

COMPATIBILITY
=============
   The Blinky example project is compatible with IOLIMEX STM32-H103
  evaluation board. By default, the project is configured to use the
  J-Link JTAG/SWD interface.

CONFIGURATION
=============
   Make sure that the following jumpers are correctly configured on the
  OLIMEX STM32-H103 evaluation board:

GETTING STARTED
===============

  1) Start the IAR Embedded Workbench for ARM.

  2) Select File->Open->Workspace...
     Open the following workspace:

     ...\STM32-H103\Blinky\Blinky.eww

  3) Run the program.

     The Blinky application is downloaded to the Embedded RAM or
     Embedded Flash memory depending of configurations on the evaluation
     board and executed.
