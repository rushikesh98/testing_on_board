This directory contains two simple projects for Stellaris LM3S.

"simple": Blink GPIOF[0], basic implementation using DriverLib
"simple_cmsis": Blink GPIOF[0], implementation with DriverLib/CMSIS_V1P0

MDK
===

Each of the directories simple and simple_cmsis contains a folder MDK,
which in turn contains the corresponding uVision project file. Double
click simple.uv2 or simple_cmsis.uv2 to load a project into uVision.

Questions? Email to info@doulos.com
