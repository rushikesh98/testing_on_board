#include <stdint.h>

#include <LM3Sxxxx.h>

/*
 * Handler for SysTick interrupt
 */
void SysTickHandler(void)
{
    unsigned char bit;

    /* read the current state of the LED pin */
    bit = GPIOPinRead(GPIO_PORTF_BASE, GPIO_PIN_0);

    /* invert the state of the bit */
    bit ^= GPIO_PIN_0;

    /* write the new value to the LED pin */
    GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_0, bit);
}

int main()
{
    /*
     * Configure clock to run from 8 MHz board crystal,
     * clock divider of 1.
     */
    SysCtlClockSet(SYSCTL_SYSDIV_1 | SYSCTL_XTAL_8MHZ |
                   SYSCTL_OSC_MAIN |SYSCTL_USE_OSC);

    /*
     * NVIC initialization
     * Set 3 bit priority group
     * Set SysTick interrupt priority to 4 (out of 0-7)
     */
    IntPriorityGroupingSet(3);
    IntPrioritySet(FAULT_SYSTICK, 4 << 5);

    /*
     * GPIOB initialization
     * Enable and configure port F0 as output and set
     * the initial state to 0 (F0 is LED on the 6965 board)
     */
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF);
    GPIOPinTypeGPIOOutput(GPIO_PORTF_BASE, GPIO_PIN_0);
    GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_0, 0);

    /*
     * SysTick initialization
     * Set SysTick period to 1/second
     * Enable SysTick for counting and generate interrupts
     */
    SysTickPeriodSet(SysCtlClockGet());
    SysTickEnable();
    SysTickIntEnable();
    IntEnable(FAULT_SYSTICK);

    /* wait forever for SysTick interrupts */
    while(1);
}
