#include <stdint.h>
#include <stdio.h>

#include "LM3S6965.h"
#define GPIO_PIN_0 1u

#if (__CM3_CMSIS_VERSION != 0x00010010) 
__CM3_CMSIS_VERSION
#    error "__CM3_CMSIS_VERSION: Unexpected CMSIS version detected" __CM3_CMSIS_VERSION
#endif

/*
 * SysTick Handler is called whenever SysTick interrupt occurs.
 * This handler toggles the output state of GPIO port F0,
 * which is the LED on the eval board.
 */
void SysTick_Handler(void)
{
    unsigned char bit;
    /*
     * Read the current state of the output.
     * The use of the GPIO pin mask array subscript is the way to
     * access only specific bits of the GPIO port.
     */
    bit = GPIOF->DATA_Bits[GPIO_PIN_0]; // *** CMSIS change ***

    /* Toggle the state of the bit. */
    bit ^= GPIO_PIN_0;

    /*
     * Set the GPIO output pin to the new state.  Again, using the
     * pin mask subscript insures that only the bit of interest
     * is affected by the write.
     */
    GPIOF->DATA_Bits[GPIO_PIN_0] = bit; // *** CMSIS change ***
}

/*
 * This is a simple application that sets up the SysTick to generate
 * a periodic interrupt, which is then used to blink an LED.
 */
int main()
{
    /*
     * Clock initialization
     */
    // Initialization moved to SystemInit() in system_LM3S.c. Clock
    // configuration now handled by #defines. Use uVision
    // configuration wizard or text editor to change.
    SystemInit();                       // *** CMSIS change ***

    /*
     * NVIC initialization
     */
    // priority configuration: 3.5
    NVIC_SetPriorityGrouping(4);        // *** CMSIS change ***
    // SysTick priority setting below

    /*
     * GPIOF initialization
     * Enable GPIO port Fa
     * Configure port F0 as output
     * set the initial state to 0 (F0 is LED on the 6965 board)
     */
    SYSCTL->RCGC2 |= 0x20;                // *** CMSIS change ***
    __NOP();                            // kill a cycle after gpio enable
    GPIOF->DEN = GPIO_PIN_0;            // *** CMSIS change ***
    GPIOF->DIR = GPIO_PIN_0;            // *** CMSIS change ***
    GPIOF->DATA_Bits[GPIO_PIN_0] = GPIO_PIN_0;   // *** CMSIS change ***

    /*
     * SysTick initialization
     */
    SysTick_Config(SystemFrequency/2);  // *** CMSIS Change ***

    // SysTick_Config() hardcodes priority. We will overwrite this.
    NVIC_SetPriority(SysTick_IRQn, 14); // *** CMSIS change ***

    while(1);
}
